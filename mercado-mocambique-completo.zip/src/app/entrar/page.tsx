 "use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase";

export default function Entrar() {
  const [email,setEmail] = useState(""); const [password,setPassword] = useState(""); const [msg,setMsg] = useState("");
  async function submit(e: React.FormEvent) { e.preventDefault(); setMsg(""); try { const supabase=createClient(); const {error}=await supabase.auth.signInWithPassword({email,password}); if(error) throw error; window.location.href="/painel"; } catch(err) { setMsg(err instanceof Error ? err.message : "Não foi possível entrar."); } }
  return <main className="container" style={{padding:"60px 0",maxWidth:520}}><a href="/" style={{color:"#138a58"}}>← Voltar ao início</a><h1>Entrar na sua conta</h1><p style={{color:"#68778b"}}>Aceda ao seu espaço no Mercado Moçambique.</p><form onSubmit={submit} style={{display:"grid",gap:14,background:"white",padding:24,border:"1px solid #e5ebf2",borderRadius:16}}><label>Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} style={field}/></label><label>Palavra-passe<input required type="password" value={password} onChange={e=>setPassword(e.target.value)} style={field}/></label><button style={button}>Entrar</button>{msg&&<p role="alert" style={{color:"#b42318"}}>{msg}</p>}</form><p style={{fontSize:14}}>Ainda não tem conta? <a href="/registar" style={{color:"#138a58"}}>Registar</a></p></main>;
}
const field: React.CSSProperties={display:"block",width:"100%",padding:12,marginTop:6,border:"1px solid #d8e0e9",borderRadius:9};
const button: React.CSSProperties={background:"#138a58",color:"white",border:0,padding:13,borderRadius:9,fontWeight:800,cursor:"pointer"};
