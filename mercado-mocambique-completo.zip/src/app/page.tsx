const services = [
  { icon: "✦", title: "Design e criatividade", desc: "Logótipos, cartazes, identidade visual e conteúdos." },
  { icon: "⌘", title: "Tecnologia e web", desc: "Sites, aplicações web e ferramentas para negócios." },
  { icon: "▤", title: "Marketing digital", desc: "Redes sociais, campanhas e estratégia de conteúdo." },
  { icon: "✎", title: "Escrita e tradução", desc: "Textos, revisão, tradução e apoio administrativo." },
  { icon: "▦", title: "Serviços para empresas", desc: "Organização, pesquisa, dados e tarefas operacionais." },
  { icon: "◈", title: "Fotografia e vídeo", desc: "Fotografia de produtos, edição e vídeos promocionais." },
];

const steps = [
  ["01", "Descubra talentos", "Explore perfis, competências e portefólios de jovens profissionais."],
  ["02", "Converse diretamente", "Use o chat privado para combinar preço, prazo e detalhes."],
  ["03", "Comece a trabalhar", "Acorde as condições diretamente com o profissional escolhido."],
];

export default function Home() {
  return (
    <main>
      <header style={{ background: "#fff", borderBottom: "1px solid #e6ebf2" }}>
        <div className="container" style={{ minHeight: 76, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 20 }}>
          <a href="/" style={{ fontWeight: 900, fontSize: 21, letterSpacing: "-.7px" }}>
            <span style={{ color: "#138a58" }}>mercado</span><span>moçambique</span>
          </a>
          <nav style={{ display: "flex", alignItems: "center", gap: 20, fontSize: 14, flexWrap: "wrap" }}>
            <a href="#servicos">Serviços</a><a href="#como-funciona">Como funciona</a>
            <a href="/entrar">Entrar</a>
            <a href="/registar" style={{ background: "#138a58", color: "white", padding: "11px 16px", borderRadius: 10, fontWeight: 700 }}>Criar conta</a>
          </nav>
        </div>
      </header>

      <section style={{ background: "linear-gradient(135deg,#0d3025 0%,#10583e 55%,#16865b 100%)", color: "white", padding: "76px 0 70px" }}>
        <div className="container" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 42, alignItems: "center" }}>
          <div>
            <div style={{ display: "inline-block", border: "1px solid #62c99c", color: "#b9f4d7", borderRadius: 999, padding: "7px 12px", fontSize: 12, fontWeight: 700, marginBottom: 22 }}>TALENTO MOÇAMBICANO • OPORTUNIDADES REAIS</div>
            <h1 style={{ fontSize: "clamp(38px,5vw,60px)", lineHeight: 1.05, letterSpacing: "-2px", margin: "0 0 22px", maxWidth: 650 }}>O talento local merece <span style={{ color: "#7ce6b3" }}>mais oportunidades.</span></h1>
            <p style={{ fontSize: 18, lineHeight: 1.7, color: "#e1f5eb", maxWidth: 590, marginBottom: 30 }}>Encontre profissionais jovens para o seu negócio ou mostre as suas competências a clientes e empresas em Moçambique.</p>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <a href="/registar?tipo=cliente" style={{ background: "#fff", color: "#10583e", padding: "14px 18px", borderRadius: 10, fontWeight: 800 }}>Encontrar profissionais ↗</a>
              <a href="/registar?tipo=empreendedor" style={{ border: "1px solid #8bdcb8", color: "#fff", padding: "14px 18px", borderRadius: 10, fontWeight: 700 }}>Sou empreendedor</a>
            </div>
            <p style={{ fontSize: 12, color: "#c8e9d9", marginTop: 20 }}>Clientes: acesso gratuito · Empreendedores: 100 MT/mês após aprovação</p>
          </div>
          <div style={{ background: "rgba(255,255,255,.08)", border: "1px solid rgba(255,255,255,.18)", borderRadius: 24, padding: 26, backdropFilter: "blur(8px)" }}>
            <div style={{ fontSize: 13, color: "#bcebd3", marginBottom: 15 }}>POR QUE USAR O MERCADO MOÇAMBIQUE?</div>
            {["Perfis profissionais e portefólios", "Contacto directo através de chat privado", "Talentos aprovados pela plataforma", "Oportunidades para crescer profissionalmente"].map((x) => <div key={x} style={{ display: "flex", gap: 12, padding: "15px 0", borderBottom: "1px solid rgba(255,255,255,.13)" }}><span style={{ color: "#7ce6b3", fontWeight: 900 }}>✓</span><span>{x}</span></div>)}
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 22, fontSize: 12, color: "#d2f3e1" }}><span>Feito para Moçambique</span><span>Valores em MT</span></div>
          </div>
        </div>
      </section>

      <section id="servicos" className="container" style={{ padding: "68px 0" }}>
        <div style={{ maxWidth: 650, marginBottom: 30 }}>
          <p style={{ color: "#138a58", fontWeight: 800, fontSize: 12, letterSpacing: 1.5 }}>CATEGORIAS</p>
          <h2 style={{ fontSize: 34, letterSpacing: "-1px", margin: "8px 0 12px" }}>Encontre o talento de que precisa</h2>
          <p style={{ color: "#627084", lineHeight: 1.7 }}>Explore áreas de serviço e encontre alguém com as competências certas para o seu projecto.</p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(230px,1fr))", gap: 16 }}>
          {services.map((s) => <article key={s.title} style={{ background: "white", border: "1px solid #e5ebf2", borderRadius: 16, padding: 22 }}>
            <div style={{ width: 44, height: 44, display: "grid", placeItems: "center", background: "#e8f8ef", color: "#138a58", borderRadius: 12, fontSize: 22 }}>{s.icon}</div>
            <h3 style={{ margin: "18px 0 8px", fontSize: 17 }}>{s.title}</h3><p style={{ color: "#68778b", lineHeight: 1.6, margin: 0, fontSize: 14 }}>{s.desc}</p>
          </article>)}
        </div>
      </section>

      <section id="como-funciona" style={{ background: "#fff", borderTop: "1px solid #e8edf3", borderBottom: "1px solid #e8edf3", padding: "65px 0" }}>
        <div className="container">
          <div style={{ maxWidth: 650, marginBottom: 30 }}><p style={{ color: "#138a58", fontWeight: 800, fontSize: 12, letterSpacing: 1.5 }}>SIMPLES E DIRECTO</p><h2 style={{ fontSize: 34, letterSpacing: "-1px", margin: "8px 0 12px" }}>Como funciona</h2><p style={{ color: "#627084", lineHeight: 1.7 }}>Da pesquisa à primeira conversa, tudo começa com três passos.</p></div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(230px,1fr))", gap: 22 }}>
            {steps.map(([n,t,d]) => <article key={n} style={{ padding: 24, border: "1px solid #e5ebf2", borderRadius: 16 }}><div style={{ color: "#138a58", fontWeight: 900, fontSize: 14 }}>{n}</div><h3 style={{ margin: "13px 0 8px" }}>{t}</h3><p style={{ color: "#68778b", lineHeight: 1.7, margin: 0 }}>{d}</p></article>)}
          </div>
        </div>
      </section>

      <section className="container" style={{ padding: "65px 0" }}>
        <div style={{ background: "#e8f8ef", borderRadius: 22, padding: "36px clamp(22px,5vw,52px)", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 25, flexWrap: "wrap" }}>
          <div><h2 style={{ margin: "0 0 10px", fontSize: 28 }}>Está pronto para dar o próximo passo?</h2><p style={{ margin: 0, color: "#49665a", lineHeight: 1.7 }}>Crie a sua conta e faça parte de uma rede de talento local.</p></div>
          <a href="/registar" style={{ background: "#138a58", color: "white", padding: "14px 18px", borderRadius: 10, fontWeight: 800 }}>Começar agora ↗</a>
        </div>
      </section>
      <footer style={{ background: "#0d3025", color: "#d7eee3", padding: "26px 0", fontSize: 13 }}><div className="container" style={{ display: "flex", justifyContent: "space-between", gap: 15, flexWrap: "wrap" }}><span>© {new Date().getFullYear()} Mercado Moçambique</span><span>Ligando talento local a oportunidades.</span></div></footer>
    </main>
  );
}
