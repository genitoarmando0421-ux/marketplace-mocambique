# Mercado Moçambique

Marketplace responsivo que liga jovens empreendedores a clientes e empresas em Moçambique.

## Stack
- Next.js (App Router) + TypeScript
- Tailwind CSS
- Supabase (Auth, PostgreSQL, Storage e Realtime)
- Preparado para publicação na Vercel

## Importante
Este ZIP é uma base inicial funcional de interface e estrutura. Antes de produção, configure Supabase, aplique as migrações SQL, teste permissões/RLS e integre e valide os pagamentos M-Pesa/e-Mola com um provedor autorizado. A confirmação de pagamentos é manual nesta versão.

## Requisitos
- Node.js 20+
- Conta GitHub
- Projeto Supabase

## Executar localmente
```bash
npm install
cp .env.example .env.local
npm run dev
```
Abra http://localhost:3000

## Configuração Supabase
1. Crie um projeto em https://supabase.com
2. Em Project Settings > API, copie Project URL e anon/public key para `.env.local`.
3. No SQL Editor, execute `supabase/schema.sql`.
4. Nunca coloque `service_role` ou segredos no navegador/repositório.

## Fluxos previstos
- Cliente: registo gratuito, pesquisa de profissionais aprovados e ativos, perfil e contacto via chat.
- Empreendedor: registo, perfil, comprovativo de pagamento, propostas, projetos e mensagens.
- Admin: aprovação de contas, verificação manual de pagamentos, gestão de categorias e denúncias.
- Subscrição de empreendedor: 100 MT/mês; ativação apenas após revisão administrativa.
