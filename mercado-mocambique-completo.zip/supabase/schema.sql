-- Execute no SQL Editor do seu projeto Supabase.
create extension if not exists pgcrypto;

create type public.account_role as enum ('cliente','empreendedor','admin');
create type public.review_status as enum ('pendente','aprovado','rejeitado');
create type public.subscription_status as enum ('inactiva','pendente','activa','expirada');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  phone text,
  city text,
  role public.account_role not null default 'cliente',
  bio text,
  skills text[] not null default '{}',
  portfolio_urls text[] not null default '{}',
  approval_status public.review_status not null default 'pendente',
  subscription_status public.subscription_status not null default 'inactiva',
  subscription_expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.payment_proofs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  amount_mzn numeric(10,2) not null check (amount_mzn = 100),
  payment_method text not null check (payment_method in ('M-Pesa','e-Mola')),
  proof_path text not null,
  status public.review_status not null default 'pendente',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  admin_note text,
  created_at timestamptz not null default now()
);

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id) on delete cascade,
  entrepreneur_id uuid references public.profiles(id) on delete set null,
  title text not null,
  description text not null,
  budget_mzn numeric(10,2),
  deadline date,
  status text not null default 'proposta' check (status in ('proposta','em_andamento','concluido','cancelado')),
  created_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id) on delete cascade,
  entrepreneur_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(client_id, entrepreneur_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  reviewer_id uuid not null references public.profiles(id) on delete cascade,
  entrepreneur_id uuid not null references public.profiles(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique(project_id, reviewer_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  reason text not null,
  status text not null default 'pendente' check (status in ('pendente','em_analise','resolvido','rejeitado')),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_table text not null,
  target_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Create a profile for every new Auth user. Role is always defaulted to cliente here;
-- change role to empreendedor via a trusted server/admin workflow, never trust client metadata.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, phone, city, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name',''),
    new.email,
    coalesce(new.raw_user_meta_data->>'phone',''),
    coalesce(new.raw_user_meta_data->>'city',''),
    'cliente'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.payment_proofs enable row level security;
alter table public.projects enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;
alter table public.audit_logs enable row level security;

-- Security helper: admin role can only be assigned by a trusted service-role/admin process.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'); $$;

create policy "profiles select self admin or visible professionals"
on public.profiles for select to authenticated
using (
  id = auth.uid()
  or public.is_admin()
  or (role = 'empreendedor' and approval_status = 'aprovado' and subscription_status = 'activa')
);

create policy "profiles update own limited by app validation"
on public.profiles for update to authenticated
using (id = auth.uid() or public.is_admin())
with check (id = auth.uid() or public.is_admin());

create policy "profiles insert own"
on public.profiles for insert to authenticated
with check (id = auth.uid() and role = 'cliente');

create policy "payment proof owner insert"
on public.payment_proofs for insert to authenticated
with check (user_id = auth.uid() and status = 'pendente');

create policy "payment proof owner or admin select"
on public.payment_proofs for select to authenticated
using (user_id = auth.uid() or public.is_admin());

create policy "payment proof admin update"
on public.payment_proofs for update to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy "project participants select"
on public.projects for select to authenticated
using (client_id = auth.uid() or entrepreneur_id = auth.uid() or public.is_admin());

create policy "client create project"
on public.projects for insert to authenticated
with check (client_id = auth.uid());

create policy "project participants update"
on public.projects for update to authenticated
using (client_id = auth.uid() or entrepreneur_id = auth.uid() or public.is_admin())
with check (client_id = auth.uid() or entrepreneur_id = auth.uid() or public.is_admin());

create policy "conversation participants select"
on public.conversations for select to authenticated
using (client_id = auth.uid() or entrepreneur_id = auth.uid() or public.is_admin());

create policy "client start conversation"
on public.conversations for insert to authenticated
with check (client_id = auth.uid());

create policy "message participants select"
on public.messages for select to authenticated
using (
  exists (
    select 1 from public.conversations c
    where c.id = conversation_id and (c.client_id = auth.uid() or c.entrepreneur_id = auth.uid())
  ) or public.is_admin()
);

create policy "message participants send"
on public.messages for insert to authenticated
with check (
  sender_id = auth.uid() and exists (
    select 1 from public.conversations c
    where c.id = conversation_id and (c.client_id = auth.uid() or c.entrepreneur_id = auth.uid())
  )
);

create policy "reviews public read"
on public.reviews for select to authenticated using (true);

create policy "client review insert"
on public.reviews for insert to authenticated
with check (reviewer_id = auth.uid());

create policy "reports reporter insert"
on public.reports for insert to authenticated
with check (reporter_id = auth.uid());

create policy "reports reporter or admin select"
on public.reports for select to authenticated
using (reporter_id = auth.uid() or public.is_admin());

create policy "admin reports update"
on public.reports for update to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy "audit logs admin select"
on public.audit_logs for select to authenticated using (public.is_admin());

-- For public discovery, use an RPC/view only after reviewing RLS and production privacy needs.
-- Never expose service_role keys in frontend code.
